//
//  File.swift
//  Navigation
//
//  Created by Igor Situn on 24.04.2022.
//

import Foundation

struct Photos {
    let image: String
}
